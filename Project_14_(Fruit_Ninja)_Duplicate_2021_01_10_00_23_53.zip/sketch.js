var sword, swordImage;
var fruit, fruitImage, fruit2Image, fruit3Image, fruit4Image;
var alien, alienImage,  alien2Image;
var gameOver, gameOverImage
var PLAY = 0;
var END = 0;
var gameState = 1;

function preload(){
  createCanvas(400,400);
  sword = createSprite(200,200,20,20);
  swordImage = loadImage("sword.png");
  sword.addImage("sword", swordImage);
  sword.scale = 0.7;

  
  
  fruitImage = loadImage("fruit1.png");
  fruit2Image = loadImage("fruit2.png");
  fruit3Image = loadImage("fruit3.png");
  fruit4Image = loadImage("fruit4.png");
 
  alien = loadImage("alien1.png");
  alien2Image = loadImage("alien2.png");
  
  gameOverImage = loadImage("gameover.png");

  
 
}

function draw(){
  if(gameState === PLAY){
  sword.x = World.MouseX;
  sword.y = World.MouseY;
drawSprites();
}
function fruits(){
  if(frameCount%60 === 0){
    r = Math.round(random(1,4));
    a = Math.round(random(1, 2));
    alien = createSprite;
    if(r == 1){
      fruit.addImage(fruitImage);
    }
    if(r == 2){
      fruit.addImage(fruit2Image);
    }
    if(r == 3){
      fruit.addImage(fruit3Image);
    }
    if(r == 4){
      fruit.addImage(fruit4Image);
    }
    if(a == 2){
      alien.addImage(alien2Image);
    }
    if(a == 1){
      alien.addImage(alienImage);
    }
  fruit.x = Math.round(random(50, 350));
    fruit.y = Math.round(random(50, 350));
    fruit.velocityX = Math.round(random(3, 8));
    fruit.velocityY = Math.round(random(3, 6));
    
    alien.x = Math.round(random(50,350));
    alien.y = Math.round(random(50, 350));
    alien.velocityX = Math.round(random(3, 8));
    alien.velocityY = Math.round(random(3, 6));
    
    alien.lifetime = Math.round(random(5, 10));
    fruit.lifetime = Math.round(random(1, 15));
  }
}



}
if(sword.isTouching(fruit)){
  fruit.destroyEach();
  playMedia("knifeSwooshSound.mp3");
}
if(sword.isTouching(alien)){
  gameState = END;
}
gameOver.visible = false;
if(gameState === END){
 gameOver.visible = true;
  gameOver.addImage(gameOverImage);
  playMedia("gameover.mp3");
fruit.visible = false;
alien.visible = false;
  
}